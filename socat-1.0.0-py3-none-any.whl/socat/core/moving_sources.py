"""
Core functionality providing access to the moving source ephem database.
"""

import uuid7 as uuid
from astropy.coordinates import ICRS
from astropy.time import Time
from astropy.units import Quantity
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from socat.database import (
    RegisteredMovingSource,
    RegisteredMovingSourceTable,
    SolarSystemObject,
    statements,
)
from socat.database.sources import utc_datetime


async def create_ephem(
    session: AsyncSession,
    sso_id: uuid.UUID,
    MPC_id: int | None,
    name: str,
    time: Time,
    position: ICRS,
    flux: Quantity | None = None,
) -> RegisteredMovingSource:
    """
    Create a new solar system ephemeris point in the database.

    Parameters
    ----------
    session : AsyncSession
        Session to use
    sso_id : uuid.UUID
        Internal SO ID of source
    MPC_id : int | None
        MPC ID of source
    name : str
        Name of source
    time : Time
        Time of source ephem
    position : AstroPydanticICRS
        Position of source at time in ICRS coordinates
    flux : Quantity  | None
        Flux of source at ephem point in mJy

    Returns
    -------
    ephem.to_model() : RegisteredMovingSource
        Created ephem point
    """

    if flux is not None:
        flux = flux.to_value("mJy")
    ephem = RegisteredMovingSourceTable(
        sso_id=sso_id,
        MPC_id=MPC_id,
        name=name,
        time=utc_datetime(time),
        ra_deg=position.ra.to_value("deg"),
        dec_deg=position.dec.to_value("deg"),
        flux_mJy=flux,
    )

    async with session.begin():
        session.add(ephem)
        await session.commit()

    return ephem.to_model()


async def get_ephem(
    ephem_id: uuid.UUID, session: AsyncSession
) -> RegisteredMovingSource:
    """
    Get a solar system ephemeris point from the database.

    Parameters
    ----------
    ephem_id : uuid.UUID
        ID of solar system ephemeris point
    session : AsyncSession
        Asynchronous session to use

    Returns
    -------
    ephem.to_model() : RegisteredMovingSource
        Requested ephemeris point

    Raises
    ------
    ValueError
        If the ephemeris point is not found.
    """
    ephem = await session.get(RegisteredMovingSourceTable, ephem_id)

    if ephem is None:
        raise ValueError(f"Ephemeris point with ID {ephem_id} not found")

    return ephem.to_model()


async def get_ephem_points(
    source: SolarSystemObject, t_min: Time, t_max: Time, session: AsyncSession
) -> list[RegisteredMovingSource]:
    """
    Get all solar system ephemeris points for a given source within a time range.

    Parameters
    ----------
    source : SolarSystemObject
        Source for which to get ephemeris points
    t_min : Time
        Minimum time of ephemeris points to retrieve
    t_max : Time
        Maximum time of ephemeris points to retrieve
    session : AsyncSession
        Asynchronous session to use

    Returns
    -------
    list[RegisteredMovingSource]
        List of requested ephemeris points
    """
    ephems = await session.execute(
        statements.get_ephem_points(sso_id=source.sso_id, t_min=t_min, t_max=t_max)
    )

    return [e.to_model() for e in ephems.scalars()]


async def get_ephem_by_sso_id(
    sso_id: uuid.UUID, session: AsyncSession
) -> list[RegisteredMovingSource]:
    """
    Get all solar system ephemeris points for a given source.

    Parameters
    ----------
    sso_id : uuid.UUID
        Internal ID of source for which to get ephemeris points
    session : AsyncSession
        Asynchronous session to use

    Returns
    -------
    list[RegisteredMovingSource]
        List of requested ephemeris points

    """
    ephems = await session.execute(
        select(RegisteredMovingSourceTable).where(
            RegisteredMovingSourceTable.sso_id == sso_id
        )
    )

    return [e.to_model() for e in ephems.scalars()]


async def update_ephem(
    ephem_id: uuid.UUID,
    session: AsyncSession,
    sso_id: uuid.UUID | None,
    MPC_id: int | None,
    name: str | None,
    time: Time | None,
    position: ICRS | None,
    flux: Quantity | None = None,
) -> RegisteredMovingSource:
    """
    Create a new solar system ephemeris point in the database.

    Parameters
    ----------
    ephem_id : uuid.UUID
        ID of ephem.
    session : AsyncSession
        Session to use
    sso_id : uuid.UUID | None
        Internal SO ID of source
    MPC_id : int | None
        MPC ID of source
    name : str | None
        Name of source
    time : Time | None
        Time of source ephem
    position : AstroPydanticICRS | None
        Position of source in ICRS coordinates
    flux : Quantity  | None
        Flux of source at ephem point in mJy

    Returns
    -------
    ephem.to_model() : RegisteredMovingSource
        updated ephemeris point

    Raises
    ------
    ValueError
        If the ephemeris point is not found.
    """

    async with session.begin():
        await session.execute(
            statements.update_ephem(
                ephem_id=ephem_id,
                sso_id=sso_id,
                MPC_id=MPC_id,
                name=name,
                time=time,
                position=position,
                flux=flux,
            )
        )
        ephem = await session.get(RegisteredMovingSourceTable, ephem_id)

        if ephem is None:
            raise ValueError(f"Ephem point with ID {ephem_id} not found.")

        model = ephem.to_model()

        await session.commit()

    return model


async def delete_ephem(ephem_id: uuid.UUID, session: AsyncSession) -> None:
    """
    Delete a solar system ephemeris point from the dattabase.

    Parameters
    ----------
    ephem_id : uuid.UUID
        ID of ephemeris point to delete
    session : AsyncSession
        Asynchronous session to use

    Returns
    -------
    None

    Raises
    ------
    ValueError
        If the ephem point is not found.
    """

    async with session.begin():
        ephem = await session.get(RegisteredMovingSourceTable, ephem_id)

        if ephem is None:
            raise ValueError(f"Source with ID {ephem_id} not found")

        await session.delete(ephem)
        await session.commit()
