"""
Uses a SQLAlchemy database connection to implement the client core.
"""

from collections.abc import Callable
from contextlib import AbstractContextManager
from typing import Any

import uuid7 as uuid
from astropy.coordinates import ICRS
from astropy.time import Time
from astropy.units import Quantity
from sqlalchemy import select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker

from socat.core import SourceGenerator
from socat.database import (
    AstroqueryService,
    AstroqueryServiceTable,
    RegisteredFixedSource,
    RegisteredFixedSourceTable,
    RegisteredMovingSource,
    RegisteredMovingSourceTable,
    SolarSystemObject,
    SolarSystemObjectTable,
    statements,
)
from socat.database.session import (
    create_sync_session_factory,
    create_sync_session_interface,
)
from socat.database.sources import utc_datetime

from .core import (
    AstroqueryClientBase,
    ClientBase,
    EphemClientBase,
    SolarSystemClientBase,
)


class Client(ClientBase):
    """
    DB-backed client implementation for fixed sources.
    """

    _get_session: Callable[[], AbstractContextManager]

    def __init__(
        self,
        *,
        db_url: str | None = None,
        engine: Engine | None = None,
        session_factory: sessionmaker | None = None,
    ):
        if session_factory is None:
            session_factory = create_sync_session_factory(
                db_url=db_url,
                engine=engine,
            )
        self._session_factory = session_factory
        self._get_session = create_sync_session_interface(
            db_url=db_url,
            engine=engine,
            session_factory=session_factory,
        )

        self._astroquery = AstorqueryClient(session_factory=session_factory)
        self._sso = SolarSystemClient(session_factory=session_factory)
        self._ephem = EphemClient(session_factory=session_factory)

    def create_source(
        self,
        *,
        position: ICRS,
        name: str | None = None,
        flux: Quantity | None = None,
        flags: dict | None = None,
    ) -> RegisteredFixedSource:
        if flux is not None:
            flux = flux.to_value("mJy")

        if flags is None:
            flags = {}

        source = RegisteredFixedSourceTable(
            ra_deg=position.ra.to_value("deg"),
            dec_deg=position.dec.to_value("deg"),
            name=name,
            flux_mJy=flux,
            monitored=flags.get("monitored", False),
            pointing=flags.get("pointing", False),
        )
        with self._get_session() as session:
            session.add(source)
            session.commit()
            session.refresh(source)

        return source.to_model()

    def create_name(
        self, *, name: str, astroquery_service: str
    ) -> RegisteredFixedSource:
        position, name, flux = statements.create_name(name, astroquery_service)

        return self.create_source(position=position, name=name, flux=flux)

    def get_box_fixed(
        self,
        *,
        lower_left: ICRS,
        upper_right: ICRS,
    ) -> list[RegisteredFixedSource]:
        # TODO: add logic for boxes that wrap around RA=0/360
        with self._get_session() as session:
            sources = session.execute(
                statements.get_box_fixed(lower_left=lower_left, upper_right=upper_right)
            )

            return [s.to_model() for s in sources.scalars().all()]

    def get_source(self, *, source_id: uuid.UUID) -> RegisteredFixedSource | None:
        with self._get_session() as session:
            source = session.get(RegisteredFixedSourceTable, source_id)
            if source is None:
                raise ValueError(f"Source with ID {source_id} not found")
            return source.to_model()

    def get_monitored_sources(
        self, *, t_min: Time, t_max: Time
    ) -> list[SourceGenerator]:
        with self._get_session() as session:
            fixed_result = session.execute(statements.get_monitored_fixed_sources())
            fixed_sources = [s.to_model() for s in fixed_result.scalars().all()]

            sso_result = session.execute(
                statements.get_monitored_ssos(t_min=t_min, t_max=t_max)
            )
            sso_sources = [s.to_model() for s in sso_result.scalars().all()]

        return [
            self.get_source_generator(source=s, t_min=t_min, t_max=t_max)
            for s in fixed_sources + sso_sources
        ]

    def get_pointing_sources(
        self, *, t_min: Time, t_max: Time
    ) -> list[SourceGenerator]:
        with self._get_session() as session:
            fixed_result = session.execute(statements.get_pointing_fixed_sources())
            fixed_sources = [s.to_model() for s in fixed_result.scalars().all()]

            sso_result = session.execute(
                statements.get_pointing_ssos(t_min=t_min, t_max=t_max)
            )
            sso_sources = [s.to_model() for s in sso_result.scalars().all()]

        return [
            self.get_source_generator(source=s, t_min=t_min, t_max=t_max)
            for s in fixed_sources + sso_sources
        ]

    def update_source(
        self,
        *,
        source_id: uuid.UUID,
        position: ICRS | None = None,
        name: str | None = None,
        flux: Quantity | None = None,
        flags: dict | None = None,
    ) -> RegisteredFixedSource | None:
        with self._get_session() as session:
            session.execute(
                statements.update_source(
                    source_id=source_id,
                    position=position,
                    name=name,
                    flux=flux,
                    flags=flags,
                )
            )
            source = session.get(RegisteredFixedSourceTable, source_id)

            if source is None:
                raise ValueError(
                    f"Unable to update and/or find source with ID {source_id}"
                )

            model = source.to_model()

            session.commit()

            return model

    def delete_source(self, *, source_id: uuid.UUID) -> None:
        with self._get_session() as session:
            source = session.get(RegisteredFixedSourceTable, source_id)
            if source is None:
                return

            session.delete(source)
            session.commit()

    def create_service(self, *, name: str, config: dict[str, Any]) -> AstroqueryService:
        return self._astroquery.create_service(name=name, config=config)

    def get_service(self, *, service_id: uuid.UUID) -> AstroqueryService | None:
        return self._astroquery.get_service(service_id=service_id)

    def get_service_name(self, *, name: str) -> list[AstroqueryService] | None:
        return self._astroquery.get_service_name(name=name)

    def update_service(
        self,
        *,
        service_id: uuid.UUID,
        name: str | None,
        config: dict[str, Any] | None,
    ) -> AstroqueryService | None:
        return self._astroquery.update_service(
            service_id=service_id, name=name, config=config
        )

    def delete_service(self, *, service_id: uuid.UUID) -> None:
        return self._astroquery.delete_service(service_id=service_id)

    def create_ephem(
        self,
        *,
        sso_id: uuid.UUID,
        MPC_id: int | None,
        name: str,
        time: Time,
        position: ICRS,
        flux: Quantity | None = None,
    ) -> RegisteredMovingSource:
        return self._ephem.create_ephem(
            sso_id=sso_id,
            MPC_id=MPC_id,
            name=name,
            time=time,
            position=position,
            flux=flux,
        )

    def get_ephem(self, *, ephem_id: uuid.UUID) -> RegisteredMovingSource | None:
        return self._ephem.get_ephem(ephem_id=ephem_id)

    def get_ephem_points(
        self,
        *,
        sso_id: uuid.UUID,
        t_min: Time,
        t_max: Time,
    ) -> list[RegisteredMovingSource] | None:
        return self._ephem.get_ephem_points(sso_id=sso_id, t_min=t_min, t_max=t_max)

    def update_ephem(
        self,
        *,
        ephem_id: uuid.UUID,
        sso_id: uuid.UUID | None,
        MPC_id: int | None,
        name: str | None,
        time: Time | None,
        position: ICRS | None,
        flux: Quantity | None,
    ) -> RegisteredMovingSource | None:
        return self._ephem.update_ephem(
            ephem_id=ephem_id,
            sso_id=sso_id,
            MPC_id=MPC_id,
            name=name,
            time=time,
            position=position,
            flux=flux,
        )

    def delete_ephem(self, *, ephem_id: uuid.UUID) -> None:
        return self._ephem.delete_ephem(ephem_id=ephem_id)

    def create_sso(
        self, *, name: str, MPC_id: int | None, flags: dict | None = None
    ) -> SolarSystemObject:
        return self._sso.create_sso(name=name, MPC_id=MPC_id, flags=flags)

    def get_sso(self, *, sso_id: uuid.UUID) -> SolarSystemObject | None:
        return self._sso.get_sso(sso_id=sso_id)

    def get_box_sso(
        self,
        *,
        lower_left: ICRS,
        upper_right: ICRS,
        t_min: Time,
        t_max: Time,
    ) -> list[SolarSystemObject] | None:
        with self._get_session() as session:
            sources = session.execute(
                statements.get_box_sso(
                    lower_left=lower_left,
                    upper_right=upper_right,
                    t_min=t_min,
                    t_max=t_max,
                )
            )

            return [s.to_model() for s in sources.scalars()]

    def get_box(
        self,
        *,
        lower_left: ICRS,
        upper_right: ICRS,
        t_min: Time,
        t_max: Time,
    ) -> list[SourceGenerator] | None:
        fixed_sources: list[RegisteredFixedSource] = self.get_box_fixed(
            lower_left=lower_left,
            upper_right=upper_right,
        )
        sso_sources: list[SolarSystemObject] = self.get_box_sso(
            lower_left=lower_left,
            upper_right=upper_right,
            t_min=t_min,
            t_max=t_max,
        )

        return [
            self.get_source_generator(
                source=s,
                t_min=t_min,
                t_max=t_max,
            )
            for s in fixed_sources + sso_sources
        ]

    def get_sso_name(self, *, name: str) -> list[SolarSystemObject] | None:
        return self._sso.get_sso_name(name=name)

    def get_sso_MPC_id(self, *, MPC_id: int) -> list[SolarSystemObject] | None:
        return self._sso.get_sso_MPC_id(MPC_id=MPC_id)

    def update_sso(
        self, *, sso_id: uuid.UUID, name: str | None, MPC_id: int | None
    ) -> SolarSystemObject | None:
        return self._sso.update_sso(sso_id=sso_id, name=name, MPC_id=MPC_id)

    def delete_sso(self, *, sso_id: uuid.UUID) -> None:
        return self._sso.delete_sso(sso_id=sso_id)

    def get_source_generator(
        self,
        source: RegisteredFixedSource | SolarSystemObject,
        t_min: Time,
        t_max: Time,
    ) -> SourceGenerator:
        """
        SourceGenerator factory method.

        Parameters
        ----------
        source : RegisteredFixedSource | SolarSystemObject
            The source to generate for.
        t_min : Time
            The minimum time to generate for.
        t_max : Time
            The maximum time to generate for.

        Returns
        -------
        SourceGenerator
            A SourceGenerator for the given source and time range.
        """
        ephems = None
        if isinstance(source, SolarSystemObject):
            with self._get_session() as session:
                ephems = session.execute(
                    statements.get_ephem_points(
                        sso_id=source.sso_id, t_min=t_min, t_max=t_max
                    )
                )
                ephems = [e.to_model() for e in ephems.scalars().all()]
        return SourceGenerator(source=source, ephems=ephems)


class AstorqueryClient(AstroqueryClientBase):
    """
    DB-backed client implementation for astroquery services.
    """

    _get_session: Callable[[], AbstractContextManager]

    def __init__(
        self,
        *,
        db_url: str | None = None,
        engine: Engine | None = None,
        session_factory: sessionmaker | None = None,
    ):
        self._get_session = create_sync_session_interface(
            db_url=db_url,
            engine=engine,
            session_factory=session_factory,
        )

    def create_service(self, *, name: str, config: dict[str, Any]) -> AstroqueryService:
        service = AstroqueryServiceTable(name=name, config=config)

        with self._get_session() as session:
            session.add(service)
            session.commit()
            session.refresh(service)

            return service.to_model()

    def get_service(self, *, service_id: uuid.UUID) -> AstroqueryService | None:
        with self._get_session() as session:
            service = session.get(AstroqueryServiceTable, service_id)

            if service is None:
                raise ValueError(f"Service with ID {service_id} not found.")

            return service.to_model()

    def get_service_name(self, *, name: str) -> list[AstroqueryService] | None:
        with self._get_session() as session:
            services = session.execute(
                select(AstroqueryServiceTable).where(
                    AstroqueryServiceTable.name == name
                )
            )

            service_list = [s.to_model() for s in services.scalars().all()]
            if len(service_list) == 0:
                raise ValueError(f"Service with name {name} not found.")

            return service_list

    def update_service(
        self,
        *,
        service_id: uuid.UUID,
        name: str | None,
        config: dict[str, Any] | None,
    ) -> AstroqueryService | None:
        with self._get_session() as session:
            session.execute(
                statements.update_service(
                    service_id=service_id, name=name, config=config
                )
            )
            service = session.get(AstroqueryServiceTable, service_id)

            if service is None:
                raise ValueError(f"Source with ID {service_id} not found")

            model = service.to_model()
            session.commit()

            return model

    def delete_service(self, *, service_id: uuid.UUID) -> None:
        with self._get_session() as session:
            service = session.get(AstroqueryServiceTable, service_id)
            if service is None:
                return

            session.delete(service)
            session.commit()


class EphemClient(EphemClientBase):
    """
    DB-backed client implementation for moving-source ephemerides.
    """

    _get_session: Callable[[], AbstractContextManager]

    def __init__(
        self,
        *,
        db_url: str | None = None,
        engine: Engine | None = None,
        session_factory: sessionmaker | None = None,
    ):
        self._get_session = create_sync_session_interface(
            db_url=db_url,
            engine=engine,
            session_factory=session_factory,
        )

    def create_ephem(
        self,
        *,
        sso_id: uuid.UUID,
        MPC_id: int | None,
        name: str,
        time: Time,
        position: ICRS,
        flux: Quantity | None = None,
    ) -> RegisteredMovingSource:
        flux_mJy = None if flux is None else flux.to_value("mJy")

        ephem = RegisteredMovingSourceTable(
            sso_id=sso_id,
            MPC_id=MPC_id,
            name=name,
            time=utc_datetime(time),
            ra_deg=position.ra.to_value("deg"),
            dec_deg=position.dec.to_value("deg"),
            flux_mJy=flux_mJy,
        )

        with self._get_session() as session:
            session.add(ephem)
            session.commit()
            session.refresh(ephem)

            return ephem.to_model()

    def get_ephem(self, *, ephem_id: uuid.UUID) -> RegisteredMovingSource | None:
        with self._get_session() as session:
            ephem = session.get(RegisteredMovingSourceTable, ephem_id)

            if ephem is None:
                raise ValueError(f"Ephemeris point with ID {ephem_id} not found")

            return ephem.to_model()

    def get_ephem_points(
        self,
        *,
        sso_id: uuid.UUID,
        t_min: Time,
        t_max: Time,
    ) -> list[RegisteredMovingSource]:
        with self._get_session() as session:
            ephems = session.execute(
                statements.get_ephem_points(sso_id=sso_id, t_min=t_min, t_max=t_max)
            )

            return [e.to_model() for e in ephems.scalars().all()]

    def update_ephem(
        self,
        *,
        ephem_id: uuid.UUID,
        sso_id: uuid.UUID | None,
        MPC_id: int | None,
        name: str | None,
        time: Time | None,
        position: ICRS | None,
        flux: Quantity | None,
    ) -> RegisteredMovingSource | None:
        with self._get_session() as session:
            session.execute(
                statements.update_ephem(
                    ephem_id=ephem_id,
                    sso_id=sso_id,
                    MPC_id=MPC_id,
                    name=name,
                    time=time,
                    position=position,
                    flux=flux,
                )
            )

            ephem = session.get(RegisteredMovingSourceTable, ephem_id)

            if ephem is None:
                raise ValueError(f"Ephemeris point with ID {ephem_id} not found")

            model = ephem.to_model()

            session.commit()

        return model

    def delete_ephem(self, *, ephem_id: uuid.UUID) -> None:
        with self._get_session() as session:
            ephem = session.get(RegisteredMovingSourceTable, ephem_id)
            if ephem is None:
                return

            session.delete(ephem)
            session.commit()


class SolarSystemClient(SolarSystemClientBase):
    """
    DB-backed client implementation for solar system objects.
    """

    _get_session: Callable[[], AbstractContextManager]

    def __init__(
        self,
        *,
        db_url: str | None = None,
        engine: Engine | None = None,
        session_factory: sessionmaker | None = None,
    ):
        if session_factory is None:
            session_factory = create_sync_session_factory(
                db_url=db_url,
                engine=engine,
            )
        self._session_factory = session_factory
        self._get_session = create_sync_session_interface(
            session_factory=session_factory,
        )

    def create_sso(
        self, *, name: str, MPC_id: int | None, flags: dict | None = None
    ) -> SolarSystemObject:
        if flags is None:
            flags = {}

        source = SolarSystemObjectTable(
            name=name,
            MPC_id=MPC_id,
            monitored=flags.get("monitored", False),
            pointing=flags.get("pointing", False),
        )

        with self._get_session() as session:
            session.add(source)
            session.commit()
            session.refresh(source)

            return source.to_model()

    def get_sso(self, *, sso_id: uuid.UUID) -> SolarSystemObject | None:
        with self._get_session() as session:
            source = session.get(SolarSystemObjectTable, sso_id)

            if source is None:
                raise ValueError(f"Source with ID {sso_id} not found.")

            return source.to_model()

    def get_sso_name(self, *, name: str) -> list[SolarSystemObject] | None:
        with self._get_session() as session:
            sources = session.execute(
                select(SolarSystemObjectTable).where(
                    SolarSystemObjectTable.name == name
                )
            )

            source_list = [s.to_model() for s in sources.scalars().all()]
            if len(source_list) == 0:
                raise ValueError(f"Source with name {name} not found.")

            return source_list

    def get_sso_MPC_id(self, *, MPC_id: int) -> list[SolarSystemObject] | None:
        with self._get_session() as session:
            sources = session.execute(
                select(SolarSystemObjectTable).where(
                    SolarSystemObjectTable.MPC_id == MPC_id
                )
            )

            source_list = [s.to_model() for s in sources.scalars().all()]
            if len(source_list) == 0:
                raise ValueError(f"Source with MPC ID {MPC_id} not found.")

            return source_list

    def update_sso(
        self, *, sso_id: uuid.UUID, name: str | None, MPC_id: int | None
    ) -> SolarSystemObject | None:
        with self._get_session() as session:
            session.execute(
                statements.update_sso(sso_id=sso_id, name=name, MPC_id=MPC_id)
            )
            source = session.get(SolarSystemObjectTable, sso_id)

            if source is None:
                raise ValueError(f"Source with SSO ID {sso_id} not found")

            model = source.to_model()

            session.commit()

        return model

    def delete_sso(self, *, sso_id: uuid.UUID) -> None:
        with self._get_session() as session:
            source = session.get(SolarSystemObjectTable, sso_id)
            if source is None:
                return

            session.delete(source)
            session.commit()
